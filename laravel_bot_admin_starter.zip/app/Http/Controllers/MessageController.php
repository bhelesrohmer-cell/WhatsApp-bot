<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;

class MessageController extends Controller {
    public function handle(Request $request){
        return response()->json([
            "reply"=>"🤖 Bot connecté avec succès"
        ]);
    }
}
