<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\MessageController;

Route::post('/message',[MessageController::class,'handle']);
